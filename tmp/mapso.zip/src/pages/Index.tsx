import { AssessmentProvider, useAssessment } from "@/contexts/AssessmentContext";
import LandingSection from "@/components/LandingSection";
import OrgSetupForm from "@/components/OrgSetupForm";
import QuestionnaireForm from "@/components/QuestionnaireForm";
import ResultsDashboard from "@/components/ResultsDashboard";

const AssessmentFlow = () => {
  const { currentStep } = useAssessment();

  switch (currentStep) {
    case "landing":
      return <LandingSection />;
    case "org-setup":
      return <OrgSetupForm />;
    case "questionnaire":
      return <QuestionnaireForm />;
    case "results":
      return <ResultsDashboard />;
    default:
      return <LandingSection />;
  }
};

const Index = () => (
  <AssessmentProvider>
    <AssessmentFlow />
  </AssessmentProvider>
);

export default Index;
